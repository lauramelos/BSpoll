<?php

/**
 * sfTCPDF actions.
 *
 * @package    sfTCPDFPlugin
 * @author     Vernet Loïc aka COil <qrf_coil@yahoo.fr>
 * @since      16 march 2007
 */

require_once(dirname(__FILE__).'/../lib/BasesfTCPDFActions.class.php');

class sfTCPDFActions extends BasesfTCPDFActions
{
}
