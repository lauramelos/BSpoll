<h1>Edit Mg gallery</h1>

<?php include_partial('form', array('form' => $form)) ?>
