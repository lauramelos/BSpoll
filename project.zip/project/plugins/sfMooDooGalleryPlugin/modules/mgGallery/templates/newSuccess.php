<h1>New Mg gallery</h1>

<?php include_partial('form', array('form' => $form)) ?>
