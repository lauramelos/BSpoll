<li>
  <?php echo mdg_photo_tag($options['size'], $mg_photo) ?>
</li>