<h1>New Mg photo</h1>

<?php include_partial('form', array('form' => $form)) ?>
