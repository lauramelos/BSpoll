<?php

/**
 * sfMooDooPermission module configuration.
 *
 * @package    sfMooDooPlugin
 * @subpackage sfMooDooPermission
 * @author     Fabien Potencier
 * @version    SVN: $Id: sfMooDooPermissionGeneratorConfiguration.class.php 23319 2009-10-25 12:22:23Z Kris.Wallsmith $
 */
class sfMooDooPermissionGeneratorConfiguration extends BaseSfMooDooPermissionGeneratorConfiguration
{
}
