<?php

/**
 * sfMooDooGroup module configuration.
 *
 * @package    sfMooDooPlugin
 * @subpackage sfMooDooGroup
 * @author     Fabien Potencier
 * @version    SVN: $Id: sfMooDooGroupGeneratorConfiguration.class.php 23319 2009-10-25 12:22:23Z Kris.Wallsmith $
 */
class sfMooDooGroupGeneratorConfiguration extends BaseSfMooDooGroupGeneratorConfiguration
{
}
