<?php

/**
 * sfMooDooGroup module helper.
 *
 * @package    sfMooDooPlugin
 * @subpackage sfMooDooGroup
 * @author     Fabien Potencier
 * @version    SVN: $Id: sfMooDooGroupGeneratorHelper.class.php 23319 2009-10-25 12:22:23Z Kris.Wallsmith $
 */
class sfMooDooGroupGeneratorHelper extends BaseSfMooDooGroupGeneratorHelper
{
}
