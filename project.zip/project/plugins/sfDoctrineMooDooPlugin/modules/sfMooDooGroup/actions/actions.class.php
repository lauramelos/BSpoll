<?php

require_once dirname(__FILE__).'/../lib/sfMooDooGroupGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/sfMooDooGroupGeneratorHelper.class.php';

/**
 * sfMooDooGroup actions.
 *
 * @package    sfMooDooPlugin
 * @subpackage sfMooDooGroup
 * @author     Fabien Potencier
 * @version    SVN: $Id: actions.class.php 23319 2009-10-25 12:22:23Z Kris.Wallsmith $
 */
class sfMooDooGroupActions extends autosfMooDooGroupActions
{
}
