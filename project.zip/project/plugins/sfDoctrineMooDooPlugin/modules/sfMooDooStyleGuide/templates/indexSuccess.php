<h1>Tests</h1>
<ul>
  <li><h2>Form elements</h2></li>
  <li><?php echo link_to ('input Date', 'mooDooTest/inputDate') ?></li>
</ul>

<ul>
  <li><h2>Interface</li>
  <li><?php echo link_to ('Overlay', 'mooDooTest/overlay') ?></li>
</ul>