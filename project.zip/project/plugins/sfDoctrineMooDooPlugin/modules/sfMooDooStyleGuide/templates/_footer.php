<div id='footer'>
  <p>Desarrollado por <a href="http://www.xifox.net" target="_blank" class="xifox">XiFOX.net</a></p>
</div>