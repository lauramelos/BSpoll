<?php

/**
 * Permission model.
 *
 * @package    sfDoctrineMooDooPlugin
 * @subpackage model
 * @author     Fabien Potencier <fabien.potencier@symfony-project.com>
 * @version    SVN: $Id: PluginsfGuardUser.class.php 24633 2009-12-01 01:34:47Z Jonathan.Wage $
 */
class sfMooDooPermission extends sfGuardPermission {

}
