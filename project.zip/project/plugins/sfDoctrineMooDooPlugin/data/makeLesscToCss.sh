lessc data/stylesheets/mooDoo.2/generator.global.less web/css/generator.global.css
lessc data/stylesheets/mooDoo.2/generator.default.less web/css/generator.default.css

lessc data/stylesheets/mooDoo.2/generator.edit.less web/css/generator.edit.css
lessc data/stylesheets/mooDoo.2/generator.list.less web/css/generator.list.css
