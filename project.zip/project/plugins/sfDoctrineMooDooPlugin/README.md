sfDoctrineDooPlugin
===================

[www.xifox.net/sfPropelMooDooPlugin] (http://www.xifox.net/sfPropelMooDooPlugin).
