<?php

/**
 * Base project form.
 * 
 * @package    limbo
 * @subpackage form
 * @author     Damian Suarez / Laura Melo 
 * @version    SVN: $Id: BaseForm.class.php 20147 2009-07-13 11:46:57Z FabianLange $
 */
class BaseForm extends sfFormSymfony
{
}
