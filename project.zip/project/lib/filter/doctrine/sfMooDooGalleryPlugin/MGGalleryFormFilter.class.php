<?php

/**
 * MGGallery filter form.
 *
 * @package    limbo
 * @subpackage filter
 * @author     Damian Suarez / Laura Melo
 * @version    SVN: $Id: sfDoctrinePluginFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class MGGalleryFormFilter extends PluginMGGalleryFormFilter
{
  public function configure()
  {
  }
}
